package com.sisp;

import com.sisp.beans.HttpResponseEntity;
import com.sisp.common.utils.UUIDUtil;
import com.sisp.controller.*;
import com.sisp.dao.ProjectEntityMapper;
import com.sisp.dao.UserEntityMapper;
import com.sisp.dao.entity.*;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;


import org.junit.jupiter.api.Test;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.io.InputStream;
import java.util.List;
import org.apache.log4j.Logger;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
class DemoApplicationTests {
//    @Test
//    void contextLoads() {
    //@Resource
    //private UserController userController;
    //    }
    //Logger log = Logger.getLogger(DemoApplicationTests.class);


    @Resource
    private PeopleController peopleController;
    private ProblemController problemController;
    private ProjectController projectController;
    private QuestionController questionController;
    private QuestionnaireController questionnaireController;
    private UserController userController;
    private XuanxiangController xuanxiangController;
    //    }
    Logger log = Logger.getLogger(DemoApplicationTests.class);
    @Test
    public void testSelect(){


        PeopleEntity peopleEntity = new PeopleEntity();
        peopleEntity.setPeoplename("1");
        //peopleEntity.setPeoplename("zdv fsgbdfnhgc");
        HttpResponseEntity httpResponseEntity = peopleController.queryPeopleList(peopleEntity);
        log.info("---结果---");
        log.info(httpResponseEntity.getData().toString());

        //ProblemEntity problemEntity = new ProblemEntity();
        //problemEntity.setId("1");
        ////problemEntity.setId("zdv fsgbdfnhgc");
        //HttpResponseEntity httpResponseEntity = problemController.queryProblemList(problemEntity);
        //log.info("---结果---");
        //log.info(httpResponseEntity.getData().toString());

        //ProjectEntity projectEntity = new ProjectEntity();
        //projectEntity.setId("1");
        ////projectEntity.setId("zdv fsgbdfnhgc");
        //HttpResponseEntity httpResponseEntity = projectController.queryProjectList(projectEntity);
        //log.info("---结果---");
        //log.info(httpResponseEntity.getData().toString());

        //QuestionEntity questionEntity = new QuestionEntity();
        //questionEntity.setUuid("1");
        ////questionEntity.setUuid("zdv fsgbdfnhgc");
        //HttpResponseEntity httpResponseEntity = questionController.queryQuestionList(questionEntity);
        //log.info("---结果---");
        //log.info(httpResponseEntity.getData().toString());

        //QuestionnaireEntity questionnaireEntity = new QuestionnaireEntity();
        //questionnaireEntity.setUid("1");
        ////questionnaireEntity.setUid("zdv fsgbdfnhgc");
        //HttpResponseEntity httpResponseEntity = questionnaireController.queryQuestionnaireList(questionnaireEntity);
        //log.info("---结果---");
        //log.info(httpResponseEntity.getData().toString());

        //UserEntity userEntity = new UserEntity();
        //userEntity.setUsername("1");
        ////userEntity.setUsername("zdv fsgbdfnhgc");
        //HttpResponseEntity httpResponseEntity = userController.queryUserList(userEntity);
        //log.info("---结果---");
        //log.info(httpResponseEntity.getData().toString());

        //XuanxiangEntity xuanxiangEntity = new XuanxiangEntity();
        //xuanxiangEntity.setId("1");
        ////xuanxiangEntity.setId("zdv fsgbdfnhgc");
        //HttpResponseEntity httpResponseEntity = xuanxiangController.queryXuanxiangList(xuanxiangEntity);
        //log.info("---结果---");
        //log.info(httpResponseEntity.getData().toString());
    }


    //@Test
    public void queryUserList() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建UserMapper对象，mybatis自动生成mapper代理对象
        UserEntityMapper userEntityMapper = sqlSession.getMapper(UserEntityMapper.class);
        //调用userMapper的方法
        UserEntity userEntity = new UserEntity();
        List<UserEntity> list = userEntityMapper.queryUserList(userEntity);
        if(CollectionUtils.isEmpty(list)){
            // 记录error级别的信息
        }else{
            System.out.println(list);
            // 记录info级别的信息
            log.info(">>queryUserList用户列表查询测试成功");
        }
    }

    //@Test
    public void selectUserInfo() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建UserMapper对象，mybatis自动生成mapper代理对象
        UserEntityMapper userEntityMapper = sqlSession.getMapper(UserEntityMapper.class);
        //调用userMapper的方法
        UserEntity userEntity = new UserEntity();
        userEntity.setUsername("1");
        userEntity.setPassword("1");
        List<UserEntity> list = userEntityMapper.selectUserInfo(userEntity);
        if(CollectionUtils.isEmpty(list)){
            // 记录error级别的信息
        }else{
            System.out.println(list);
            // 记录info级别的信息
            log.info(">>qselectUserInfo用户登录测试成功");
        }
    }

    //@Test
    public void insert() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建UserMapper对象，mybatis自动生成mapper代理对象
        UserEntityMapper userEntityMapper = sqlSession.getMapper(UserEntityMapper.class);
        //调用userMapper的方法
        UserEntity userEntity = new UserEntity();
        userEntity.setId(UUIDUtil.getOneUUID());
        userEntity.setStatus("1");
        userEntity.setUsername("LS");
        userEntity.setPassword("123");
        int i = userEntityMapper.insert(userEntity);
        if(i==0){
            // 记录error级别的信息
        }else{
            System.out.println(i);
            // 记录info级别的信息
            log.info(">>insert用户插入测试成功");
        }
    }

    //@Test
    public void deleteUserById() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建UserMapper对象，mybatis自动生成mapper代理对象
        UserEntityMapper userEntityMapper = sqlSession.getMapper(UserEntityMapper.class);
        //调用userMapper的方法
        UserEntity userEntity = new UserEntity();
        userEntity.setId("2");
        int i = userEntityMapper.deleteUserById(userEntity);
        if(i==0){
            // 记录error级别的信息
        }else{
            System.out.println(i);
            // 记录info级别的信息
            log.info(">>delete用户删除测试成功");
        }
    }

    //项目相关测试
    //@Test
    public void queryProjectList() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建ProjectMapper对象，mybatis自动生成mapper代理对象
        ProjectEntityMapper projectEntityMapper = sqlSession.getMapper(ProjectEntityMapper.class);
        //调用projectMapper的方法
        ProjectEntity projectEntity = new ProjectEntity();
        List<ProjectEntity> list = projectEntityMapper.queryProjectList(projectEntity);
        if(CollectionUtils.isEmpty(list)){
            // 记录error级别的信息
        }else{
            System.out.println(list);
            // 记录info级别的信息
            log.info(">>queryProjectList项目列表查询测试成功");
        }
    }



    //@Test
    public void insertProject() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建ProjectMapper对象，mybatis自动生成mapper代理对象
        ProjectEntityMapper projectEntityMapper = sqlSession.getMapper(ProjectEntityMapper.class);
        //调用projectEntity的方法
        ProjectEntity projectEntity = new ProjectEntity();
        projectEntity.setId(UUIDUtil.getOneUUID());
        projectEntity.setProjectName("第N个项目");
        projectEntity.setProjectContent("项目描述");
        int i = projectEntityMapper.insertProject(projectEntity);
        if(i==0){
            // 记录error级别的信息
        }else{
            System.out.println(i);
            // 记录info级别的信息
            log.info(">>insert项目插入测试成功");
        }
    }

    //@Test
    public void deleteProjectById() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建ProjectMapper对象，mybatis自动生成mapper代理对象
        ProjectEntityMapper projectEntityMapper = sqlSession.getMapper(ProjectEntityMapper.class);
        //调用projectEntity的方法
        ProjectEntity projectEntity = new ProjectEntity();

        int i = projectEntityMapper.deleteProjectById(projectEntity);
        if(i==0){
            // 记录error级别的信息
        }else{
            System.out.println(i);
            // 记录info级别的信息
            log.info(">>delete项目删除测试成功");
        }
    }
    //@Test
    public void updateByPrimaryKeySelective() throws Exception {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建ProjectMapper对象，mybatis自动生成mapper代理对象
        ProjectEntityMapper projectEntityMapper = sqlSession.getMapper(ProjectEntityMapper.class);
        //调用projectEntity的方法
        ProjectEntity projectEntity = new ProjectEntity();
        projectEntity.setProjectName("修改后的项目名称");
        projectEntity.setProjectContent("修改后的项目描述");
        int result = projectEntityMapper.updateByPrimaryKeySelective(projectEntity);
        if(result==0){
            // 记录error级别的信息
        }else{
            System.out.println(result);
            // 记录info级别的信息
            log.info("updateProject:编辑项目测试成功");
        }
    }
}



