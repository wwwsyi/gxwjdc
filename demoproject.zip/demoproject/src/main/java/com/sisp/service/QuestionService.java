package com.sisp.service;

import com.sisp.common.utils.UUIDUtil;
import com.sisp.dao.QuestionEntityMapper;
import com.sisp.dao.entity.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class QuestionService {
    @Autowired
    private QuestionEntityMapper questionEntityMapper;

    /*
    查询问卷列表
     */
    public List<QuestionEntity> queryQuestionList(QuestionEntity questionEntity) {

        List<QuestionEntity> result = questionEntityMapper.queryQuestionList(questionEntity);

        return result;

    }

    /*
    创建用户
     */
    public int addQuestionInfo(QuestionEntity questionEntity) {
        questionEntity.setUuid(UUIDUtil.getOneUUID());

        int questionResult = questionEntityMapper.insertQuestion(questionEntity);
        if (questionResult != 0) {
            return 3;//数字3表示问卷存在
        } else {
            return questionResult;
        }
    }
}