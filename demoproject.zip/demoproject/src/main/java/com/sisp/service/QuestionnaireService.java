package com.sisp.service;

import com.sisp.common.utils.UUIDUtil;
import com.sisp.dao.ProjectEntityMapper;
import com.sisp.dao.QuestionnaireEntityMapper;
import com.sisp.dao.entity.ProjectEntity;
import com.sisp.dao.entity.QuestionnaireEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionnaireService {
    @Autowired
    private QuestionnaireEntityMapper questionnaireEntityMapper;

    //查询项目列表
    public List<QuestionnaireEntity> questionnaireEntityList(QuestionnaireEntity questionnaireEntity){
        List<QuestionnaireEntity> result = questionnaireEntityMapper.queryQuestionnaireList(questionnaireEntity);
        return result;
    }

    //创建项目
    public int addQuestionnaireInfo(QuestionnaireEntity questionnaireEntity) {
        questionnaireEntity.setUid(UUIDUtil.getOneUUID());

        int questionnaireResult = questionnaireEntityMapper.insertQuestionnaire(questionnaireEntity);
        if (questionnaireResult != 0) {
            return 3;//数字3代表用户存在}
        } else {
            return questionnaireResult;
        }
    }

    //修改项目信息
    public int modifyQuestionnaireInfo(QuestionnaireEntity questionnaireEntity ) {

        int questionnaireResult = questionnaireEntityMapper.updateByPrimaryKeySelectivee(questionnaireEntity);
        return questionnaireResult;
    }
    //删除项目信息
    public int deleteQuestionnaireById(QuestionnaireEntity questionnaireEntity){
        int questionnaireResult = questionnaireEntityMapper.deleteQuestionnaireById(questionnaireEntity);
        return questionnaireResult;
    }

}
