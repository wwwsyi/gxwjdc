package com.sisp.service;

import com.sisp.common.utils.UUIDUtil;
import com.sisp.dao.ProblemEntityMapper;
import com.sisp.dao.entity.ProblemEntity;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProblemService {
    @Autowired
    private ProblemEntityMapper problemEntityMapper;

    /*
    查询用户列表
     */
    public List<ProblemEntity> queryProblemList(ProblemEntity problemEntity){

        List<ProblemEntity> result = problemEntityMapper.queryProblemList(problemEntity);

        return result;

    }
    /*
        创建问卷题目题型
         */
    public int addProblemInfo(ProblemEntity problemEntity){
        problemEntity.setId(UUIDUtil.getOneUUID());

        int problemResult = problemEntityMapper.insertProblem(problemEntity);
        if (problemResult != 0){
            return 3;//数字3表示用户存在
        }else{
            return problemResult;
        }
    }

    /*
    删除用户信息
     */
    public int deleteProblemById(ProblemEntity problemEntity){
        problemEntity.setStatus("0");

        int problemResult = problemEntityMapper.deleteProblemById(problemEntity);
        return problemResult;
    }
    /*
        修改用户信息
         */
    public int modifyProblem(ProblemEntity problemEntity){
        int problemResult = problemEntityMapper.modifyProblem(problemEntity);
        return problemResult;
    }
}