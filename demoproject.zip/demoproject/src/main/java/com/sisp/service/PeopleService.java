package com.sisp.service;

import com.sisp.dao.PeopleEntityMapper;
import com.sisp.dao.UserEntityMapper;
import com.sisp.dao.entity.PeopleEntity;
import com.sisp.dao.entity.ProjectEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PeopleService {
    @Autowired
    private PeopleEntityMapper peopleEntityMapper;

    //查询项目列表
    public List<PeopleEntity> queryPeopleList(PeopleEntity peopleEntity){
        List<PeopleEntity> result = peopleEntityMapper.queryPeopleList(peopleEntity);
        return result;
    }

    public List<PeopleEntity> selectPeopleInfo(PeopleEntity peopleEntity){
        List<PeopleEntity> result = peopleEntityMapper.selectPeopleInfo(peopleEntity);
        return result;
    }
}
