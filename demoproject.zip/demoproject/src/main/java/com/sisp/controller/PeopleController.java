package com.sisp.controller;

import com.sisp.beans.HttpResponseEntity;
import com.sisp.dao.entity.PeopleEntity;
import com.sisp.dao.entity.ProjectEntity;
import com.sisp.service.PeopleService;
import com.sisp.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PeopleController {
    @Autowired
    private PeopleService peopleService;

    //项目列表查询
    @RequestMapping(value = "/queryPeopleList",method = RequestMethod.POST,headers = "Accept=application/json")
    public HttpResponseEntity queryPeopleList(@RequestBody PeopleEntity peopleEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();

        try{
            List<PeopleEntity> hasPeople = peopleService.queryPeopleList(peopleEntity);
            if (CollectionUtils.isEmpty(hasPeople)){
                httpResponseEntity.setCode("0");
                httpResponseEntity.setData(hasPeople.get(0));
                httpResponseEntity.setMessage("无答卷人信息");
            }else {
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(hasPeople);
                httpResponseEntity.setMessage("查询成功");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return httpResponseEntity;
    }

    //项目列表查询
    @RequestMapping(value = "/selectPeopleInfo",method = RequestMethod.POST,headers = "Accept=application/json")
    public HttpResponseEntity selectPeopleInfo(@RequestBody PeopleEntity peopleEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();

        try{
            List<PeopleEntity> hasPeople = peopleService.selectPeopleInfo(peopleEntity);
            if (CollectionUtils.isEmpty(hasPeople)){
                httpResponseEntity.setCode("0");
//                httpResponseEntity.setData(hasPeople.get(0));
                httpResponseEntity.setMessage("无答卷人的信息");
            }else {
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(hasPeople);
                httpResponseEntity.setMessage("查询成功");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return httpResponseEntity;
    }
}
