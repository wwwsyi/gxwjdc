package com.sisp.dao;

import com.sisp.dao.entity.ProblemEntity;
import com.sisp.dao.entity.ProjectEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@Mapper
public interface ProblemEntityMapper {
    /**
     * 查询用户列表
     **/
    List<ProblemEntity> queryProblemList(ProblemEntity problemEntity);

    /**
     * 创建用户的基本信息
     **/
    int insertProblem(ProblemEntity problemEntity);
    /*
     *根据id删除用户信息
     */
    int deleteProblemById(ProblemEntity problemEntity);

    int modifyProblem(ProblemEntity problemEntity);

}