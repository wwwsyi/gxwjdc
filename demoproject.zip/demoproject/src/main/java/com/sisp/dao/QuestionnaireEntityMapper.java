package com.sisp.dao;

import com.sisp.dao.entity.QuestionnaireEntity;
import com.sisp.dao.entity.UserEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@Mapper
public interface QuestionnaireEntityMapper {
    /**
     *查询题目列表
     **/
    List<QuestionnaireEntity> queryQuestionnaireList(QuestionnaireEntity questionnaireEntity);
    /**
     *创建题目的基本信息
     * */
    int insertQuestionnaire(QuestionnaireEntity questionnaireEntity);
    /**
     *根据uid删除题目信息
     **/
    int deleteQuestionnaireById(QuestionnaireEntity questionnaireEntity);
    /**
     *编辑题目信息
     */
    int updateByPrimaryKeySelectivee(QuestionnaireEntity questionnaireEntity);

}
