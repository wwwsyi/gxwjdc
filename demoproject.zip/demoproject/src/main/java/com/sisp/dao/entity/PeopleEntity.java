package com.sisp.dao.entity;

public class PeopleEntity {
    private String pid;
    private String questionid;
    private String peoplename;
    private String answertime;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getQuestionid() {
        return questionid;
    }

    public void setQuestionid(String questionid) {
        this.questionid = questionid;
    }

    public String getPeoplename() {
        return peoplename;
    }

    public void setPeoplename(String peoplename) {
        this.peoplename = peoplename;
    }

    public String getAnswertime() {
        return answertime;
    }

    public void setAnswertime(String answertime) {
        this.answertime = answertime;
    }

    @Override
    public String toString() {
        return "PeopleEntity{" +
                "pid='" + pid + '\'' +
                ", questionid='" + questionid + '\'' +
                ", peoplename='" + peoplename + '\'' +
                ", answertime='" + answertime + '\'' +
                '}';
    }
}
