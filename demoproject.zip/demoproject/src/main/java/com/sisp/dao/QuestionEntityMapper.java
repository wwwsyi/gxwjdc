package com.sisp.dao;

import com.sisp.dao.entity.QuestionEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@Mapper
public interface QuestionEntityMapper {

    /**
     * 查询问卷列表，进入到问卷编辑页面
     **/
    List<QuestionEntity> queryQuestionList(QuestionEntity questionEntity);

    /**
     * 创建问卷的基本信息
     **/
    int insertQuestion(QuestionEntity questionEntity);

}