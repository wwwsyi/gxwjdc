package com.sisp.dao;

import com.sisp.dao.entity.PeopleEntity;
import com.sisp.dao.entity.UserEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@Mapper
public interface PeopleEntityMapper {
    /**
     *查询用户列表
     **/
    List<PeopleEntity> queryPeopleList(PeopleEntity peopleEntity);
    /**
     *创建用户的基本信息
     * */
    int insertPeople(PeopleEntity peopleEntity);
    /**
     *根据id删除用户信息
     **/
    int deletePeopleById(PeopleEntity peopleEntity);
    /**
     *编辑用户信息
     */
    int updateByPrimaryKeySelective(PeopleEntity peopleEntity);

    //查询用户
    List<PeopleEntity> selectPeopleInfo(PeopleEntity peopleEntity);
}
