package com.sisp.dao;

import com.sisp.dao.entity.XuanxiangEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface XuanxiangEntityMapper {
    /**
     * 查询用户列表
     **/
    List<XuanxiangEntity> queryXuanxiangList(XuanxiangEntity xuanxiangEntity);

    /**
     * 创建用户的基本信息
     **/
    int insertXuanxiang(XuanxiangEntity xuanxiangEntity);
    /*
     *根据id删除用户信息
     */
    int deleteXuanxiangById(XuanxiangEntity xuanxiangEntity);
    /*
    编辑用户信息
     */
    int modifyXuanxiangInfo(XuanxiangEntity xuanxiangEntity);
    /*
    查询用户
     */
    List<XuanxiangEntity> selectXuanxiangInfo(XuanxiangEntity xuanxiangEntity);

}