package com.sisp.dao.entity;

import java.io.Serializable;

public class ProblemEntity implements Serializable {
    private String id;
    private String questionContent;
    private String questionnaireId;
    private String questionType;
    private String questionMust;
    private String questionOrder;
    private String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuestionContent() {
        return questionContent;
    }

    public void setQuestionContent(String questionContent) {
        this.questionContent = questionContent;
    }

    public String getQuestionnaireId() {
        return questionnaireId;
    }

    public void setQuestionnaireId(String questionnaireId) {
        this.questionnaireId = questionnaireId;
    }

    public String getQuestionType() {
        return questionType;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public String getQuestionMust() {
        return questionMust;
    }

    public void setQuestionMust(String questionMust) {
        this.questionMust = questionMust;
    }

    public String getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(String questionOrder) {
        this.questionOrder = questionOrder;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ProblemEntity{" +
                "id='" + id + '\'' +
                ", questionContent='" + questionContent + '\'' +
                ", questionnaireId='" + questionnaireId + '\'' +
                ", questionType='" + questionType + '\'' +
                ", questionMust='" + questionMust + '\'' +
                ", questionOrder='" + questionOrder + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}