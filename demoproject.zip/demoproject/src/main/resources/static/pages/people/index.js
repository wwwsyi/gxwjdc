onload = () => {
  $('#headerUsername').text($util.getItem('userInfo').username)
  $('#headerDivB').text('答卷人管理')
  fetchPeopleList()
}

let pageNum = 1
let peopleList = []

const fetchPeopleList = () => {
  let params = {
    pageNum,
    pageSize: 10,
    userName: $('#username').val()
  }
  $.ajax({
    url: API_BASE_URL + '/queryPeopleList',
    type: 'POST',
    data: JSON.stringify(params),
    dataType: 'json',
    contentType: 'application/json',
    success(res) {
      $('#table #tbody').html('')
      peopleList = res.data
      res.data.map((item, index) => {
        $('#table #tbody').append(`
          <tr>
            <td>${index + 1}</td>
            <td>${item.pid}</td>
            <td>${item.questionid}</td>
            <td>${item.peoplename}</td>
            <td>${item.answertime}</td>
            <td>
              
              <button type="button" class="btn btn-link" onclick="onSeePeople('${item.id}')">明细</button>
              
            </td>
          </tr>
        `)
      })
    }
  })


}


const handleTableChange = (page) => {
  if (page === 1) {
    if (pageNum === 1) return
    pageNum--
  } else if (page === 2) {
    pageNum++
  } else if (page === 3) {
    pageNum = +$('#goNum').val()
  }
  $('#currentPage').text(pageNum)
  fetchPeopleList()
}

function handleCreateQuestionnaire() {
  var input = document.getElementById('peoplename');
  var inputValue = input.value;

  // 在这里处理输入值，可以将它作为参数传递给其他函数或进行其他操作
  // 示例：打印输入值到控制台

  let params = {
    peoplename:inputValue
  }
  $.ajax({
    url: API_BASE_URL + '/selectPeopleInfo',
    type: 'POST',
    data: JSON.stringify(params),
    dataType: 'json',
    contentType: 'application/json',
    success(res) {
      $('#table #tbody').html('')
      peopleList = res.data
      res.data.map((item, index) => {
        $('#table #tbody').append(`
          <tr>
            <td>${index + 1}</td>
            <td>${item.pid}</td>
            <td>${item.questionid}</td>
            <td>${item.peoplename}</td>
            <td>${item.answertime}</td>
            <td>
              
              <button type="button" class="btn btn-link" onclick="onSeePeople('${item.id}')">明细</button>
              
            </td>
          </tr>
        `)
      })
    }
  })
}

const onSeePeople = (id) => {
  let people = peopleList.filter(item => item.id === id)[0]
  $util.setPageParam('people', people)
  location.href = '/pages/mingxi/index.html'
}

