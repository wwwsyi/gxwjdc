onload = () => {
  $('#headerUsername').text($util.getItem('userInfo').username)
  $('#headerDivB').text('问题')
  fetchQuestionnaireList()
}

let pageNum = 1
let questionnaireList = []

const fetchQuestionnaireList = () => {
  let params = {
    pageNum,
    pageSize: 10,
    userName: $('#username').val()
  }
  $.ajax({
    url: API_BASE_URL + '/queryQuestionnaireList',
    type: 'POST',
    data: JSON.stringify(params),
    dataType: 'json',
    contentType: 'application/json',
    success(res) {
      $('#table #tbody').html('')
      questionnaireList  = res.data
      res.data.map((item, index) => {
        $('#table #tbody').append(`
          <tr>
            <td>${index + 1}</td>
            <td>${item.uid}</td>
            <td>${item.questionnairetype}</td>
            <td>${item.questionnairecontent}</td>
            
            <td>
              <button type="button" class="btn btn-link" onclick="handleEdit('${item.id}')">编辑</button>
              <button type="button" class="btn btn-link btn-red" onclick="deleteQuestionnaire('${item.id}')">删除</button>
            </td>
          </tr>
        `)
      })
    }
  })
}
const deleteQuestionnaire = (id) => {
  let params = {
    id: id
  }
  $.ajax({
    url: API_BASE_URL + '/deleteQuestionnaireinfo',
    type: 'POST',
    data: JSON.stringify(params),
    dataType: 'json',
    contentType: 'application/json',
    success(res) {
      fetchQuestionnaireList()
    }
  })
}
const handleTableChange = (page) => {
  if (page === 1) {
    if (pageNum === 1) return
    pageNum--
  } else if (page === 2) {
    pageNum++
  } else if (page === 3) {
    pageNum = +$('#goNum').val()
  }
  $('#currentPage').text(pageNum)
  fetchQuestionnaireList()
}

const handleCreateQuestionnaire = () => {
  $util.setPageParam('questionnaire', undefined)
  location.href = '/pages/xqne/index.html'
}

const handleEdit = (id) => {
  let questionnaire = questionnaireList.filter(item => item.id === id)[0]
  $util.setPageParam('questionnaire', questionnaire)
  location.href = '/pages/xqne/index.html'
}
