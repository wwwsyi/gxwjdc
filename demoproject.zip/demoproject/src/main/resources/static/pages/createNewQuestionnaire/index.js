
onload = () => {
  $('#headerUsername').text($util.getItem('userInfo').username)
  $('#headerDivB').text('创建调查问卷')

  $('#startTime').datetimepicker({
    language: 'zh-CN', // 显示中文
    format: 'yyyy-mm-dd', // 显示格式
    minView: "month", // 设置只显示到月份
    initialDate: new Date(), // 初始化当前日期
    autoclose: true, // 选中自动关闭
    todayBtn: true // 显示今日按钮
  })
  $('#endTime').datetimepicker({
    language: 'zh-CN', // 显示中文
    format: 'yyyy-mm-dd', // 显示格式
    minView: "month", // 设置只显示到月份
    initialDate: new Date(), // 初始化当前日期
    autoclose: true, // 选中自动关闭
    todayBtn: true // 显示今日按钮
  })

  let questonnaire = $util.getPageParam('questionnaire')
  // console.log('--- 用户信息 ---');
  // console.log(user);
  if (questonnaire) {
    $('#questionnaireTitle').val(questonnaire.questionnaireTitle)
    $('#questionnaireDescription').val(questonnaire.questionnaireDescription)
    $('#startDate').val(questonnaire.startTime)
    $('#endDate').val(questonnaire.endTime)
  }
}

const handleCreateQuestionnaire = () => {

  let questionnaire = $util.getPageParam('questionnaire');
  let projectId = $util.getPageParam('projectId');
  let projectType = $util.getPageParam('projectType');
  let result
  if(projectType == 1){
    result = '教师'
  }else{
    result = '学生'
  }
  if (!questionnaire) {
    questionnaire = {};
  }

  questionnaire.questionnaireTitle = $('#surveyName').val();
  questionnaire.questionnaireDescription = $('#surveyDescription').val();
  questionnaire.startTime = $('#startDate').val() && new Date($('#startDate').val()).getTime();
  questionnaire.endTime = $('#endDate').val() && new Date($('#endDate').val()).getTime();

  questionnaire.projectId = projectId;
  questionnaire.projectType = result;

  $util.setPageParam('questionnaire', questionnaire);

  if (!questionnaire.questionnaireTitle) return alert('问卷名称不能为空！')
  if (!questionnaire.questionnaireDescription) return alert('问卷描述不能为空！')
  alert(questionnaire.questionnaireTitle + '#' + questionnaire.questionnaireDescription + '#' + questionnaire.startTime + '#' + questionnaire.endTime)


  $.ajax({
    url: API_BASE_URL + '/addQuestionInfo',
    type: 'POST',
    data: JSON.stringify(questionnaire),
    dataType: 'json',
    contentType: 'application/json',
    success(res) {
      if (res.code === "666") {
        $.ajax({
          url: API_BASE_URL + '/queryQuestionList',
          type: "POST",
          data: JSON.stringify(questionnaire),
          dataType: "json",
          contentType: "application/json",
          success(res) {
            QueryList = res.data
            res.data.map(item => {
              if (questionnaire.questionnaireTitle == item.questionnaireTitle) {
                const idQuestionnaire = item.id;
                localStorage.setItem('questionnaireId', idQuestionnaire);
                alert("准备跳转;"+idQuestionnaire+";")
                location.href = '/pages/designQuestionnaire/index.html?questionnaireId=' + localStorage.getItem('questionnaireId');
              }
            })
          }
        })
      } else {
        alert(res.message)
      }
    }
  })

}