onload = () => {
  $('#headerUsername').text($util.getItem('userInfo').username)
  $('#headerDivB').text('编辑问题')



  let questionnaire = $util.getPageParam('questionnaire')

  if (questionnaire) {
    $('#uid').val(questionnaire.uid)
    $('#questionnairetype').val(questionnaire.questionnairetype)
    $('#questionnairecontent').val(questionnaire.questionnairecontent)

  }
}

const handleCreateQuestionnaire = () => {

  if (!$('#uid').val()) return alert('编号不能为空！')
  if (!$('#questionnairetype').val()) return alert('类型不能为空！')
  if (!$('#questionnairecontent').val()) return alert('内容不能为空！')


  let questionnaire = $util.getPageParam('questionnaire');
  console.log('--- questionnaire ---')
  console.log(questionnaire);
  if (!questionnaire) {
    questionnaire = {};
  }

  questionnaire.uid = $('#uid').val();
  questionnaire.questionnairetype = $('#questionnairetype').val();
  questionnaire.questionnairecontent = $('#questionnairecontent').val();

  // 修改
  if (questionnaire.uid) {

    $.ajax({
      url: API_BASE_URL + '/modifyQuestionnaireInfo',
      type: 'POST',
      data: JSON.stringify(questionnaire),
      dataType: 'json',
      contentType: 'application/json',
      success(res) {
        if (res.code === "666") {
          location.href = '/pages/qne/index.html'
        } else {
          alert(res.message)
        }
      }
    })

  } else {
    // 新建
    $.ajax({
      url: API_BASE_URL + '/addQuestionnaireInfo',
      type: 'POST',
      data: JSON.stringify(questionnaire),
      dataType: 'json',
      contentType: 'application/json',
      success(res) {
        if (res.code === "666") {
          location.href = '/pages/qne/index.html'
        } else {
          alert(res.message)
        }
      }
    })
  }
}

